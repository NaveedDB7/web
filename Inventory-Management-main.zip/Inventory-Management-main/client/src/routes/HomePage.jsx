import React from "react";
import Navbar from "../component/Navbar";

const HomePage = () => {
  return (
    <div className="aboutus">
      <Navbar />
      HomePage
    </div>
  );
};

export default HomePage;
