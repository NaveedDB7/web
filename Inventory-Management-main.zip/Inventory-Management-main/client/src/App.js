// App.js
import React, { Fragment, useState } from "react";
import "./App.css";

import Hero from "./component/Hero";

function App() {
  return (
    <Fragment>
      <Hero />
    </Fragment>
  );
}

export default App;
