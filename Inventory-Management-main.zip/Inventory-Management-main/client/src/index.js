import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import App from "./App";
import { RouterProvider, createBrowserRouter } from "react-router-dom";
import AboutUs from "./routes/AboutUs";
import Products from "./routes/Products";
import Inventory from "./routes/Inventory";
import Analytics from "./routes/Analytics";
import ChatbotEmbed from "./component/chatbot";

const router = createBrowserRouter([
  { path: "/", element: <App /> },
  { path: "/AboutUs", element: <AboutUs /> },
  { path: "/Products", element: <Products /> },
  { path: "/Inventory", element: <Inventory /> },
  { path: "/Analytics", element: <Analytics /> },
  { path: "/chatbot", element: <ChatbotEmbed /> },
]);

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
  <React.StrictMode>
    <RouterProvider router={router} />
  </React.StrictMode>,
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
